# hello-world-go-action
This is a simple Docker based (Go) Hello World action
